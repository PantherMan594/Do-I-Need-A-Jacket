# Do I Need a Jacket?

doineedajacket.tech (Domain Name doesn't redirect properly)

See the website live at https://pantherman594.github.io/Do-I-Need-A-Jacket/index.html.

We used...
* Weather Underground's API for weather data
* Google's Identity Platform to sign in and change settings
* A combination of MySQL, PHP, and MySQLi for saving settings to a database (on a remote server)
* A Github Repository for version control: https://github.com/pantherman594/Do-I-Need-A-Jacket/